export const AVATAR_API = "https://ui-avatars.com/api";
export const API = "https://sadflower-server-3c85453c8087.herokuapp.com/api";
export const AUTH_TOKEN = "authToken";
export const BEARER = "Bearer";
export const USER = "user";
