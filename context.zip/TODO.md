## TODO

[ ] Corriger la mise en page des articles dans Articles.exe (ça ne renvois pas les mises en pages de Heroku)
[ ] Mettre la liste des utilisateurs dans l'ordre du premier créer
[ ] Rajouter des popups
[ ] Rajouter des bugs/glitchs (erreur/crash = ecran bleu | duplication de fenêtres par moment | reference à des hacks/bugs connus)


[ ] Faire des articles
[ ] Faire une application musique (trouver idées)
[ ] Faire un forum
[ ] Gamifier le site (trouver idées)
