const config = {
  api: "https://sadflower-server-3c85453c8087.herokuapp.com",
};

export default config;
